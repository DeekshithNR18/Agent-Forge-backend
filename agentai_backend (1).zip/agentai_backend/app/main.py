from fastapi import FastAPI

from app.api.routes import router

app = FastAPI(
    title="Autonomous AI Engineering Team",
    description="Multi-agent autonomous software engineering backend",
    version="1.0.0"
)

app.include_router(router)


@app.get("/health")
def health_check():
    return {
        "status": "healthy",
        "service": "ai-engineering-team"
    }

import uuid

from app.orchestrator.state import ProjectState
from app.agents.registry import get_agents


class Orchestrator:

    def __init__(self):
        self.projects = {}
        self.agents = get_agents()

    def create_project(self, requirement: str):

        project = ProjectState()

        project.project_id = str(uuid.uuid4())
        project.requirement = requirement

        project.log(
            "orchestrator",
            "New software engineering project created."
        )

        self.projects[project.project_id] = project

        return project

    def start_project(self, project_id: str):

        project = self.projects.get(project_id)

        if not project:
            raise ValueError("Project not found")

        self.agents["planner"].run(project)
        self.agents["architect"].run(project)
        self.agents["coder"].run(project)
        self.agents["tester"].run(project)
        self.agents["debugger"].run(project)
        self.agents["security"].run(project)
        self.agents["deployer"].run(project)

        project.log(
            "orchestrator",
            "Autonomous software engineering workflow completed."
        )

        return project

    def start_planning(self, project_id: str):

        project = self.projects.get(project_id)

        if not project:
            raise ValueError("Project not found")

        self.agents["planner"].run(project)

        return project

    def get_project(self, project_id: str):

        return self.projects.get(project_id)
